import React from 'react';
import HomePageLayOut from './Layout/HomePageLayOut/HomePageLayOut.jsx';
import RouteComponent from './RouteComponents/RouteComponent.jsx';

function App() {
  return (
    <div>
      <RouteComponent />
    </div>
  );
}

export default App;
