import React from "react";
import "./ContactUs.css";
import PhoneCall from './ContactUsIcons/phone_call.svg';
import Message from './ContactUsIcons/message.svg';
import Location from './ContactUsIcons/location.svg';
import Insta from './ContactUsIcons/insta.svg';
import Discord from './ContactUsIcons/discord.svg';
import ClickButton from './ContactUsIcons/click_button.svg';

const ContactUs = () => {
  return (
    <div
      className="d-flex justify-content-center align-items-center contact-us-main px-2"
      style={{
        minHeight: "100vh",
        backgroundColor: "white",
        alignItems: "center",
      }}
    >
      <div className="container-fluid">
        <div className="row justify-content-center">
          <div
            className="col-lg-4 col-md-12 mb-3 contact-details"
            style={{ position: "relative", zIndex: 1 }}
          >
            <div style={{ borderRadius: "40px" }} className="card shadow">
              <div
                className="card-body"
                style={{
                  minHeight: "50vh",
                  backgroundColor: "#436B88",
                  borderRadius: "40px",
                }}
              >
                <div
                  style={{
                    fontFamily: "Helvetica Rounded",
                    fontWeight: "700px",
                  }}
                >
                  <h1 className="text-white text-center">Contact us!</h1>
                </div>
                <div className="d-flex align-items-center justify-content-center text-center">
                  <img
                    src={PhoneCall}
                    alt=""
                    style={{ marginRight: "10px", verticalAlign: "middle" }}
                  />
                  <p
                    style={{
                      color: "white",
                      display: "inline-block",
                      verticalAlign: "middle",
                      fontSize: "20px",
                      marginTop: "20px",
                      marginRight: "180px",
                    }}
                  >
                    +1012 3456 789
                  </p>
                </div>
                <div className="d-flex align-items-center justify-content-center text-center">
                  <img
                    src={Message}
                    alt=""
                    style={{ marginRight: "10px", verticalAlign: "middle" }}
                  />
                  <p
                    style={{
                      color: "white",
                      display: "inline-block",
                      verticalAlign: "middle",
                      fontSize: "20px",
                      marginTop: "20px",
                      marginRight: "160px",
                    }}
                  >
                    demo@gmail.com
                  </p>
                </div>
                <div style={{ paddingLeft: "65px" }} className="d-flex ">
                  <img
                    src={Location}
                    alt=""
                    style={{
                      marginRight: "6px",
                      verticalAlign: "middle",
                      marginBottom: "80px",
                    }}
                  />
                  <div style={{ verticalAlign: "middle", paddingLeft: "8px" }}>
                    <p
                      style={{
                        color: "white",
                        fontSize: "20px",
                        marginBottom: "0",
                      }}
                    >
                      D 148, EPIP, Kasna, <br />
                      Surajpur Site V,
                    </p>
                    <p
                      style={{
                        color: "white",
                        fontSize: "20px",
                        marginBottom: "0",
                      }}
                    >
                      Greater Noida,
                      <br /> Uttar Pradesh 201310
                    </p>
                  </div>
                </div>
                <div
                  className="social-icons"
                  style={{
                    display: "flex",
                    marginLeft: "65px",
                    marginTop: "30px",
                    paddingBottom: "12px",
                  }}
                >
                  <div style={{ margin: "0 10" }}>
                    <img
                      style={{
                        backgroundColor: "white",
                        borderRadius: "50%",
                        padding: "5px",
                      }}
                      src={Insta}
                      alt=""
                    />
                  </div>
                  <div style={{ margin: "0 10px" }}>
                    <img
                      style={{
                        backgroundColor: "white",
                        borderRadius: "50%",
                        padding: "5px",
                      }}
                      src={Discord}
                      alt=""
                    />
                  </div>
                  <div style={{ margin: "0 10px" }}>
                    <img
                      style={{
                        backgroundColor: "white",
                        borderRadius: "50%",
                        padding: "3px",
                      }}
                      src={ClickButton}
                      alt=""
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div
            className="col-lg-5 col-md-12 mb-4"
            style={{
              position: "relative",
              borderRadius: "40px",
              left: "-130px",

              top: "120px",
              zIndex: 6,
            }}
          >
            <div
              style={{
                borderRadius: "40px",
                marginRight: "10px",
                minHeight: "450px",
                backgroundColor: "rgba(255, 255, 255, 0.5)",
              }}
              className="card shadow"
            >
              <div
                style={{
                  fontFamily: "Helvetica Now Display",
                  borderRadius: "40px",
                }}
                className="card-body"
              >
                <h1 className="mt-4 text-center">
                  GET IN
                  <span
                    style={{ fontWeight: "bold", paddingLeft: "10px" }}
                    className="font-weight-bold"
                  >
                    TOUCH
                  </span>
                </h1>
                <div className="row mb-3">
                  <div className="col-md-6 mb-3">
                    <label
                      style={{ color: "#436B88", fontFamily: "Poppins" }}
                      htmlFor="name"
                    >
                      First Name
                    </label>
                    <input
                      type="text"
                      className="form-control"
                      placeholder="First Name"
                    />
                  </div>
                  <div className="col-md-6 mb-3">
                    <label
                      style={{ color: "#436B88", fontFamily: "Poppins" }}
                      htmlFor="name"
                    >
                      Last Name
                    </label>
                    <input
                      type="email"
                      className="form-control"
                      placeholder="Last Name"
                    />
                  </div>
                </div>

                <div className="row mb-3">
                  <div className="col-md-6 mb-3">
                    <label
                      style={{ color: "#436B88", fontFamily: "Poppins" }}
                      htmlFor="name"
                    >
                      Email
                    </label>
                    <input
                      type="text"
                      className="form-control"
                      placeholder="Email"
                    />
                  </div>
                  <div className="col-md-6 mb-3">
                    <label
                      style={{ color: "#436B88", fontFamily: "Poppins" }}
                      htmlFor="name"
                    >
                      Phone
                    </label>
                    <input
                      type="tel"
                      className="form-control"
                      placeholder="Phone Number"
                    />
                  </div>
                </div>

                <div className="row">
                  <div className="col-md-12">
                    <label
                      style={{ color: "#436B88", fontFamily: "p" }}
                      htmlFor="name"
                    >
                      Message
                    </label>
                    <textarea
                      className="form-control"
                      rows="3"
                      placeholder="Message"
                    ></textarea>
                  </div>
                </div>

                <div className="row mt-4">
                  <div className="col-md-4 mx-auto">
                    <button
                      style={{ height: "3rem" }}
                      className="btn btn-primary w-100"
                    >
                      Send Message
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ContactUs;