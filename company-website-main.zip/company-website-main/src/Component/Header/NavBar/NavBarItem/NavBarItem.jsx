import React, { useState } from 'react';
import { Nav, NavItem, Dropdown, DropdownToggle, DropdownMenu, DropdownItem } from 'reactstrap';
import { NavLink, useNavigate } from 'react-router-dom';
import './NavBarItem.css';

const NavBar = () => {
    const [hoveredNavItem, setHoveredNavItem] = useState(null);
    const [activeNavItem, setActiveNavItem] = useState(0);
    const [productDropdownOpen, setProductDropdownOpen] = useState(false);
    const [solutionDropdownOpen, setSolutionDropdownOpen] = useState(false);
    const navigate = useNavigate();

    const handleMouseEnter = (index) => {
        setHoveredNavItem(index);
    };

    const handleMouseLeave = () => {
        setHoveredNavItem(null);
    };

    const handleClick = (index, route) => {
        setActiveNavItem(index);
        navigate(route);
    };

    const toggleProductDropdown = () => setProductDropdownOpen((prevState) => !prevState);
    const toggleSolutionDropdown = () => setSolutionDropdownOpen((prevState) => !prevState);

    return (
        <Nav className="navbar-nav mx-auto border-top">
            <NavItem>
                <NavLink
                    to="/"
                    className={`nav-item nav-link ${activeNavItem === 0 ? 'active' : ''}`}
                    onMouseEnter={() => handleMouseEnter(0)}
                    onMouseLeave={handleMouseLeave}
                    onClick={() => handleClick(0, '/')}
                >
                    HOUSYS
                    <div className="nav-line" style={{ width: activeNavItem === 0 || hoveredNavItem === 0 ? '100%' : '0' }} />
                </NavLink>
            </NavItem>
            <NavItem>
                <Dropdown nav isOpen={productDropdownOpen} toggle={toggleProductDropdown}>
                    <NavLink
                        to="/product"
                        className={`nav-item nav-link ${activeNavItem === 1 ? 'active' : ''}`}
                        onMouseEnter={() => handleMouseEnter(1)}
                        onMouseLeave={handleMouseLeave}
                        onClick={() => handleClick(1, '/product')}
                    >
                        <DropdownToggle nav caret className="no-caret">
                            PRODUCT
                            <div className="nav-line" style={{ width: activeNavItem === 1 || hoveredNavItem === 1 ? '100%' : '0' }} />
                        </DropdownToggle>
                    </NavLink>
                    <DropdownMenu>
                        <DropdownItem onClick={() => handleClick(1, '/product/item1')}>Item 1</DropdownItem>
                        <DropdownItem onClick={() => handleClick(1, '/product/item2')}>Item 2</DropdownItem>
                        <DropdownItem onClick={() => handleClick(1, '/product/item3')}>Item 3</DropdownItem>
                        <DropdownItem onClick={() => handleClick(1, '/product/item4')}>Item 4</DropdownItem>
                        <DropdownItem onClick={() => handleClick(1, '/product/item5')}>Item 5</DropdownItem>
                        <DropdownItem onClick={() => handleClick(1, '/product/item6')}>Item 6</DropdownItem>
                    </DropdownMenu>
                </Dropdown>
            </NavItem>
            <NavItem>
                <Dropdown nav isOpen={solutionDropdownOpen} toggle={toggleSolutionDropdown}>
                    <NavLink
                        to="/solution"
                        className={`nav-item nav-link ${activeNavItem === 2 ? 'active' : ''}`}
                        onMouseEnter={() => handleMouseEnter(2)}
                        onMouseLeave={handleMouseLeave}
                        onClick={() => handleClick(2, '/solution')}
                    >
                        <DropdownToggle nav caret className="no-caret">
                            SOLUTION
                            <div className="nav-line" style={{ width: activeNavItem === 2 || hoveredNavItem === 2 ? '100%' : '0' }} />
                        </DropdownToggle>
                    </NavLink>
                    <DropdownMenu>
                        <DropdownItem onClick={() => handleClick(2, '/solution/parking-guidance-system')}>Parking Guidance System</DropdownItem>
                        <DropdownItem onClick={() => handleClick(2, '/solution/parking-management-system')}>Parking Management System</DropdownItem>
                        <DropdownItem onClick={() => handleClick(2, '/solution/item3')}>Item 3</DropdownItem>
                        <DropdownItem onClick={() => handleClick(2, '/solution/item4')}>Item 4</DropdownItem>
                        <DropdownItem onClick={() => handleClick(2, '/solution/item5')}>Item 5</DropdownItem>
                    </DropdownMenu>
                </Dropdown>
            </NavItem>
            <NavItem>
                <NavLink
                    to="/services"
                    className={`nav-item nav-link ${activeNavItem === 3 ? 'active' : ''}`}
                    onMouseEnter={() => handleMouseEnter(3)}
                    onMouseLeave={handleMouseLeave}
                    onClick={() => handleClick(3, '/services')}
                >
                    SERVICES
                    <div className="nav-line" style={{ width: activeNavItem === 3 || hoveredNavItem === 3 ? '100%' : '0' }} />
                </NavLink>
            </NavItem>
        </Nav>
    );
};

export default NavBar;
