import React from 'react';
import {
    Card,
    CardBody,
    CardTitle,
    CardSubtitle,
    CardText,
    Button,
    Row,
    Col,
} from 'reactstrap';
import './HomeProduct.css'
import BoomBarrier from '../../Container/images/boom_barrier.png';

const HomeProduct = () => {
    return (
        <div className='home-product' style={{maxWidth:'100%'}}>
            <div className="product-header mt-5">
                <h2 className='product-header-text'>
                    INNOVATIVE EMBEDDED PRODUCTS
                </h2>
                <h3 className='product-subheader-text mt-3 mb-5'>
                    Discover peace of mind with our top-notch Security Products, tailored to protect your assets. Whether <br />
                    at home, the office, or in enterprise settings, our products guarantee reliability and performance.
                </h3>
            </div>
            <div>
                <Row className="justify-content-center">
                    <Col lg="3" xl="3" className="d-flex prod-type">
                        <Card className="flex-fill">
                            <img alt="Sample" src="https://picsum.photos/300/200" />
                            <CardBody>
                                <CardTitle tag="h5">Card title</CardTitle>
                                <CardSubtitle className="mb-2 text-muted" tag="h6">Card subtitle</CardSubtitle>
                                <CardText>Some quick example text to build on the card title and make up the bulk of the card‘s content.</CardText>
                                <Button>Button</Button>
                            </CardBody>
                        </Card>
                    </Col>

                    <Col lg="9" xl="9" className='prod-main'>
                        <Row className="mb-2">
                            <Col lg="4" className="mb-2">
                                <div className='p-3' style={{ display: 'flex', width: '100%', borderRadius: '12px', overflow: 'hidden', background: '#F0F3F6' }}>
                                    <div style={{ width: '40%' }}>
                                        <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
                                            <div style={{ marginBottom: 'auto' }}>
                                                <h5>Card title</h5>
                                            </div>
                                            <div style={{ marginTop: 'auto' }}>
                                                <button>Button</button>
                                            </div>
                                        </div>
                                    </div>
                                    <div style={{ width: '60%' }}>
                                        <img alt="Sample" src={BoomBarrier} width="100%" />
                                    </div>
                                </div>
                            </Col>

                            <Col lg="4" className="mb-2">
                                <div className='p-3' style={{ display: 'flex', width: '100%', borderRadius: '12px', overflow: 'hidden', background: '#F0F3F6' }}>
                                    <div style={{ width: '40%' }}>
                                        <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
                                            <div style={{ marginBottom: 'auto' }}>
                                                <h5>Card title</h5>
                                            </div>
                                            <div style={{ marginTop: 'auto' }}>
                                                <button>Button</button>
                                            </div>
                                        </div>
                                    </div>
                                    <div style={{ width: '60%' }}>
                                        <img alt="Sample" src={BoomBarrier} width="100%" />
                                    </div>
                                </div>
                            </Col>

                            <Col lg="4" className="mb-2">
                                <div className='p-3' style={{ display: 'flex', width: '100%', borderRadius: '12px', overflow: 'hidden', background: '#F0F3F6' }}>
                                    <div style={{ width: '40%' }}>
                                        <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
                                            <div style={{ marginBottom: 'auto' }}>
                                                <h5>Card title</h5>
                                            </div>
                                            <div style={{ marginTop: 'auto' }}>
                                                <button>Button</button>
                                            </div>
                                        </div>
                                    </div>
                                    <div style={{ width: '60%' }}>
                                        <img alt="Sample" src={BoomBarrier} width="100%" />
                                    </div>
                                </div>
                            </Col>
                        </Row>

                        <Row className="mb-2">
                            <Col lg="4" className="mb-2">
                                <div className='p-3' style={{ display: 'flex', width: '100%', borderRadius: '12px', overflow: 'hidden', background: '#F0F3F6' }}>
                                    <div style={{ width: '40%' }}>
                                        <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
                                            <div style={{ marginBottom: 'auto' }}>
                                                <h5>Card title</h5>
                                            </div>
                                            <div style={{ marginTop: 'auto' }}>
                                                <button>Button</button>
                                            </div>
                                        </div>
                                    </div>
                                    <div style={{ width: '60%' }}>
                                        <img alt="Sample" src={BoomBarrier} width="100%" />
                                    </div>
                                </div>
                            </Col>

                            <Col lg="4" className="mb-2">
                                <div className='p-3' style={{ display: 'flex', width: '100%', borderRadius: '12px', overflow: 'hidden', background: '#F0F3F6' }}>
                                    <div style={{ width: '40%' }}>
                                        <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
                                            <div style={{ marginBottom: 'auto' }}>
                                                <h5>Card title</h5>
                                            </div>
                                            <div style={{ marginTop: 'auto' }}>
                                                <button>Button</button>
                                            </div>
                                        </div>
                                    </div>
                                    <div style={{ width: '60%' }}>
                                        <img alt="Sample" src={BoomBarrier} width="100%" />
                                    </div>
                                </div>
                            </Col>

                            <Col lg="4" className="mb-2">
                                <div className='p-3' style={{ display: 'flex', width: '100%', borderRadius: '12px', overflow: 'hidden', background: '#F0F3F6' }}>
                                    <div style={{ width: '40%' }}>
                                        <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
                                            <div style={{ marginBottom: 'auto' }}>
                                                <h5>Card title</h5>
                                            </div>
                                            <div style={{ marginTop: 'auto' }}>
                                                <button>Button</button>
                                            </div>
                                        </div>
                                    </div>
                                    <div style={{ width: '60%' }}>
                                        <img alt="Sample" src={BoomBarrier} width="100%" />
                                    </div>
                                </div>
                            </Col>
                        </Row>
                    </Col>
                </Row>
            </div>
        </div>
    );
};

export default HomeProduct;
