import React, { useEffect, useRef } from 'react';
import './OurClients.css'; // Ensure this file is correctly imported
import CLientImg from './OurClientImages/handshake.png';
import AppleImg from './OurClientImages/apple.png';
import DellImg from './OurClientImages/dell.png';
import AmazonImg from './OurClientImages/amazon.png';
import CanonImg from './OurClientImages/cannon.png';
import PepsiImg from './OurClientImages/pepsi (3).png';
import StarBugsImg from './OurClientImages/starbug.png';
import BmwImg from './OurClientImages/bmw.png';

const logos = [
    { src: AppleImg, name: "Apple" },
    { src: DellImg, name: "Deloitte" },
    { src: DellImg, name: "Dell" },
    { src: AmazonImg, name: "Amazon" },
    { src: CanonImg, name: "Canon" },
    { src: PepsiImg, name: "Pepsi" },
    { src: StarBugsImg, name: "Starbucks" },
    { src: BmwImg, name: "BMW" },
];

const OurClients = () => {
    const containerRef = useRef(null);

    useEffect(() => {
      const container = containerRef.current;
      if (container) {
        // Duplicate content for seamless scrolling
        const clone = container.cloneNode(true);
        container.appendChild(clone);
      }
    }, []);
    return (

        <div className="client-logos container-fluid">
            <h2>OUR CLIENTS</h2>
            <div className="row align-items-start full" >
                <div className="col-12 col-md-4">
                    <img src={CLientImg} alt="Handshake" className="handshake-img" />
                </div>
                <div className=" col-12 col-md-8 ">
                    <div className="logo-scroll scroled ">
                        <div className="logo-grid">
                            {[...logos, ...logos].map((logo, index) => (
                                <div className="logo-item" key={index}>
                                    <img src={logo.src} alt={logo.name} />
                                    <p className='cname'>{logo.name}</p>
                                </div>
                            ))}
                        </div>
                    </div>
                    <div className="logo-scroll">
                        <div className="logo-grid2">
                            {[...logos, ...logos].map((logo, index) => (
                                <div className="logo-item" key={index}>
                                    <img src={logo.src} alt={logo.name} />
                                    <p className='cname'>{logo.name}</p>
                                </div>
                            ))}
                             
                        </div>
                    </div>
                    <div className="logo-scroll">
                        <div className="logo-grid3">
                            {[...logos, ...logos].map((logo, index) => (
                                
                                <div className="logo-item" key={index}>
                                    <img src={logo.src} alt={logo.name} />
                                    <p className='cname'>{logo.name}</p>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default OurClients;
