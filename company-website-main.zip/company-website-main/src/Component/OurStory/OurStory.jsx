import React from 'react';
import {
    Card,
    CardBody,
    CardTitle,
    CardSubtitle,
    CardText,
    Button,
    Row,
    Col,
} from 'reactstrap';
import BoomBarrier from '../../Container/images/boom_barrier.png';
import story_1 from '../../Container/images/story_1.png';
import './OurStory.css'

const OurStory = () => {
    return (
        <div className="container-fluid about py-5">
            <div className="product-header mt-5">
                <h2 className='product-header-text'>
                    OUR STORY
                </h2>
                <h2 className='product-subheader-text mt-3 mb-5' style={{ fontSize: '30px' }}>
                    Next Gen Solutions For Today’s Challenge
                </h2>
            </div>
            <div className="container">
                <div className="row g-5 align-items-center">
                    <div className="col-lg-5">
                        <div className="video">
                            <img src={BoomBarrier} className="img-fluid rounded" alt="" />
                            <div className="position-absolute rounded border-5 border-top border-start border-white" style={{ bottom: 0, right: 0 }}>
                                <img src={BoomBarrier} className="img-fluid rounded" alt="" />
                            </div>
                            {/* <button type="button" className="btn btn-play" data-bs-toggle="modal" data-src="https://www.youtube.com/embed/DWRcNpR6Kdc" data-bs-target="#videoModal">
                                <span></span>
                            </button> */}
                        </div>
                    </div>
                    <div className="col-lg-6">
                        {/* <p className="fs-4 text-uppercase text-primary">About Us</p> */}
                        {/* <h1 className="display-4 mb-4">Your Best Spa, Beauty & Skin Care Center</h1> */}
                        <p className="mb-4 mt-3" style={{ fontSize: '20px', color: 'black' }}>Since 2015, Houston Systems has been on a relentless
                            journey, pioneering safety and security automation
                            solutions with unmatched innovation and quality. Picture
                            this: a world where safety isn't just a concept but a reality,
                            where businesses thrive without the constant fear of
                            security breaches. That's the vision driving us forward
                        </p>
                        {/* <div class="container"> */}
                            <div class="row justify-content-center mt-3 mb-3">
                                <div class="col-md-2">
                                    <div class="d-flex align-items-center">
                                        <div class="ms-4">
                                            <img src={story_1} alt="" class="img-responsive" />
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-2">
                                    <div class="d-flex align-items-center">
                                        <div class="ms-4">
                                            <img src={story_1} alt="" class="img-responsive" />
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-2">
                                    <div class="d-flex align-items-center">
                                        <div class="ms-4">
                                            <img src={story_1} alt="" class="img-responsive" />
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-2">
                                    <div class="d-flex align-items-center">
                                        <div class="ms-4">
                                            <img src={story_1} alt="" class="img-responsive" />
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-2">
                                    <div class="d-flex align-items-center">
                                        <div class="ms-4">
                                            <img src={story_1} alt="" class="img-responsive" />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        {/* </div> */}


                        {/* <p className="my-4">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
                        </p>
                        <p className="mb-4">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
                        </p> */}
                        <a href="#" className="btn btn-primary btn-primary-outline-0 rounded-pill py-3 px-5">Explore More</a>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default OurStory
