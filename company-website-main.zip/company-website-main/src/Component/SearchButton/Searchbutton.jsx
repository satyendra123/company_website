import React from 'react'

const Searchbutton = () => {
    return (
        <button class="btn-search btn btn-primary btn-primary-outline-0 rounded-circle btn-lg-square" data-bs-toggle="modal" data-bs-target="#searchModal"><i class="fas fa-search"></i></button>
    )
}

export default Searchbutton
