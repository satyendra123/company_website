import React, { useRef, useEffect } from 'react';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Autoplay } from 'swiper/modules';
import './Testimonials.css';
import Star from './TestimonialImages/star.png';

import ProfileImg from './TestimonialImages/profile.png';

const testimonials = [
  {
    name: 'John Doe',
    title: 'MD, Xyz',
    description: 'Fusce dapibus tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus.',
    rating: 5,
    imageUrl: {ProfileImg}
  },
  {
    name: 'Jane Smith',
    title: 'CEO, Abc Corp',
    description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc vulputate libero et velit interdum, ac aliquet odio mattis. Lorem ipsum dolor sit amet, consectetur .',
    rating: 4,
    imageUrl: {ProfileImg}
  },
  {
    name: 'Sam Johnson',
    title: 'CTO, Tech Solutions',
    description: 'Fusce dapibus tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus.',
    rating: 5,
    imageUrl: {ProfileImg}
  },
  {
    name: 'Kalika Johnson',
    title: 'CTO, Tech Solutions',
    description: 'Fusce dapibus tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus.',
    rating: 5,
    imageUrl: {ProfileImg}
  }
];

const Testimonials = () => {
  const swiperRef = useRef(null);

  const handleSlideChange = () => {
    const swiper = swiperRef.current.swiper;
    const slides = swiper.slides;
    const activeIndex = swiper.activeIndex;
    const slidesPerView = swiper.params.slidesPerView > 1 ? swiper.params.slidesPerView : 1;

    slides.forEach((slide, index) => {
      slide.classList.remove('swiper-slide-right');
      if (index > activeIndex && index <= activeIndex + slidesPerView) {
        slide.classList.add('swiper-slide-right');
      }
    });
  };

  useEffect(() => {
    handleSlideChange();
  }, []);

  return (
    <div className="testimonialslider">
    <div className="testimonial-wrapper" style={{ textAlign: 'center', padding: '10px' }}>
      <Swiper
        ref={swiperRef}
        direction="horizontal"
        loop={true}
        autoHeight={false}
        centeredSlides={true}
        slidesPerView={1}
        spaceBetween={20}
        autoplay={{
          delay: 9000,
          disableOnInteraction: false,
        }}
        breakpoints={{
          640: {
            slidesPerView: 1,
            spaceBetween: 10,
          },
          992: {
            slidesPerView: 3,
            spaceBetween: 20,
          },
         
        }}
        modules={[Autoplay]}
        onSlideChange={handleSlideChange}
        onInit={handleSlideChange}
      >
        {testimonials.map((testimonial, index) => (
          <SwiperSlide key={index} style={{ display: 'flex', justifyContent: 'center' }}>
            <div className="testimoniacard-custom" style={{ flex: '0 0 90%' }}>
              <div className="testimonialogo" style={{ backgroundImage: `url(${testimonial.imageUrl})` }}></div>
              <div className="container-custom">
                <div className="testimonianame">{testimonial.name}</div>
                <div className="testimoniatitle">{testimonial.title}</div>
                <div className="testimoniadescription">{testimonial.description}</div>
                <div className="testimoniarating">
                  {Array(testimonial.rating).fill().map((_, i) => (
                    <span key={i} className="star"><img src={Star}></img></span>
                  ))}
                </div>
              </div>
            </div>
          </SwiperSlide>
        ))}
      </Swiper>
      </div>
    </div>
  );
};

export default Testimonials;
