import React from 'react';

const ProductPageLayOut = () => {
  return (
    <>
    
    </>
  )
}

export default ProductPageLayOut;
