// src/components/Route.js
import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import HomePageLayOut from "../Layout/HomePageLayOut/HomePageLayOut";
import ProductPageLayOut from "../Layout/ProductPageLayOut/ProductPageLayOut";
import SolutionPageLayOut from "../Layout/SolutionPageLayOut/SolutionPageLayOut";
import PgsSolutionPageLayOut from "../Layout/SolutionPageLayOut/PgsSolutionPageLayOut/PgsSolutionPageLayOut";
import PmsSolutionPageLayOut from "../Layout/SolutionPageLayOut/PmsSolutionPageLayOut/PmsSolutionPageLayOut";
import NavBarMain from "../Component/Header/NavBar/NavBarMain/NavBarMain";
import Footer from "../Component/Footer/Footer";

const RouteComponent = () => {
  return (
    <Router>
      <NavBarMain />
      <Routes>
        <Route exact path="/" element={<HomePageLayOut />} />
        <Route path="/product" element={<ProductPageLayOut />} />
        <Route path="/solution" element={<SolutionPageLayOut />} />
        <Route path="/solution/parking-guidance-system" element={<PgsSolutionPageLayOut />} />
        <Route path="/solution/parking-management-system" element={<PmsSolutionPageLayOut />} />
      </Routes>
      <Footer />
    </Router>
  );
};

export default RouteComponent;
