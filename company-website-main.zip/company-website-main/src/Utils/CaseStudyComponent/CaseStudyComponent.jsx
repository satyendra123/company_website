import React from 'react';
import './CaseStudyComponent.css';

const CaseStudyComponent = ({ title, description, footerItems, image, placeholder }) => {
  return (
    <div className='case-study-component-card mt-4'>
      <div className='case-study-component-left'>
        <input className='case-study-component-card-input' type='text' placeholder={placeholder} />
        <div>
          <h3>{title}</h3>
          <p>{description}</p>
        </div>
        
        <div className='case-study-component-card-footer'>
          {footerItems.map((item, index) => (
            <div className='case-study-component-card-footer-item' key={index}>
              <div className={`case-study-component-card-button${item.middle ? '-middle' : ''}`}>
                <h3>{item.value}</h3>
              </div>
              <p className='mt-2'>{item.label}</p>
            </div>
          ))}
        </div>
      </div>

      <div className='case-study-component-right'>
        <img src={image} alt={placeholder} />
      </div>
    </div>
  );
};

export default CaseStudyComponent;
