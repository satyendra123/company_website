import React, { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import './Slider.css';

const Image = ({ index, imageUrl, backgroundColor }) => {
  const imageRef = useRef(null);

  useEffect(() => {
    gsap.fromTo(
      imageRef.current,
      { opacity: 0, scale: 0.9 },
      { opacity: 1, scale: 1, duration: 1, delay: index * 0.2 }
    );
  }, [index]);

  return (
    <li className="slider-section-image" style={{ '--background-color': backgroundColor }} ref={imageRef}>
      <div className="slider-section-image-container">
        <img src={imageUrl} alt={`Image ${index}`} />
      </div>
    </li>
  );
};

const Slider = () => {
  const images = [
    { id: 'image1', imageUrl: '/images/images1.jpeg', backgroundColor: 'red' },
    { id: 'image2', imageUrl: '/images/images2.jpeg', backgroundColor: 'yellow' },
    { id: 'image3', imageUrl: '/images/images3.jpeg', backgroundColor: 'pink' },
    { id: 'image4', imageUrl: '/images/images4.jpeg', backgroundColor: 'orange' },
  ];

  return (
    <div className="slider-section-container">
      <ul id="slider-section-images">
        {images.map((image, index) => (
          <Image key={image.id} index={index + 1} imageUrl={image.imageUrl} backgroundColor={image.backgroundColor} />
        ))}
      </ul>
    </div>
  );
};

export default Slider;
