import React from "react";
import "./SolutionLayOutContactUs.css";

const SolutionLayOutContactUs = ({
  headerText = "GET IN TOUCH",
  namePlaceholder = "Name",
  categoryPlaceholder = "Category",
  emailPlaceholder = "Email",
  phonePlaceholder = "Phone",
  messagePlaceholder = "Write Message...",
  buttonText = "Submit",
  onSubmit
}) => {
  return (
    <div className="solution-contact-us container">
      <div className="solution-contact-us-header">
        <p>{headerText}</p>
      </div>
      <div className="contact-form">
        <div className="form-group">
          <input
            type="text"
            placeholder={namePlaceholder}
            className="input-field solution-contact-us-mb-2"
          />
          <input
            type="text"
            placeholder={categoryPlaceholder}
            className="input-field"
          />
        </div>
        <div className="form-group">
          <input
            type="email"
            placeholder={emailPlaceholder}
            className="input-field solution-contact-us-mb-2"
          />
          <input type="tel" placeholder={phonePlaceholder} className="input-field" />
        </div>
        <div className="form-group">
          <textarea
            placeholder={messagePlaceholder}
            className="textarea-field"
          ></textarea>
        </div>
        <div className="form-group">
          <button type="submit" className="submit-button" onClick={onSubmit}>
            {buttonText}
          </button>
        </div>
      </div>
    </div>
  );
};

export default SolutionLayOutContactUs;
